//
//  AKAudioFileMarker.m
//  EDL
//
//  Created by Ryan Francesconi on 10/29/16.
//  Copyright © 2016 Spongefork. All rights reserved.
//

#import "EZAudioFileMarker.h"

@implementation EZAudioFileMarker

@end
